import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Howl } from 'howler'
import { useWeather } from './hooks/useWeather'
import WeatherBackground from './components/WeatherBackground'
import WeatherCard from './components/WeatherCard'
import SearchBar from './components/SearchBar'

const soundConfig = {
  rain: { src: ['/sounds/thunder_loop.wav'], volume: 0.6, loop: true },
  thunderstorm: { src: ['/sounds/thunder_loop.wav'], volume: 0.6, loop: true },
  snow: { src: ['/sounds/wind_loop.mp3'], volume: 0.2, loop: true },
  mist: { src: ['/sounds/wind_loop.mp3'], volume: 0.1, loop: true },
  clear: { src: ['/sounds/wind_loop.mp3'], volume: 0.03, loop: true },
  clouds: { src: ['/sounds/wind_loop.mp3'], volume: 0.05, loop: true },
}

export default function App() {
  const { weather, loading, error, fetchWeather, getWeatherType, cityHour, cityMinute } = useWeather()
  const [weatherType, setWeatherType] = useState('clear')
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [showWelcome, setShowWelcome] = useState(true)
  const [hour, setHour] = useState(new Date().getHours())
  const [soundTrigger, setSoundTrigger] = useState(0)
  const currentSound = useRef(null)
  const localInterval = useRef(null)

  
  useEffect(() => {
    localInterval.current = setInterval(() => {
      if (!weather) setHour(new Date().getHours())
    }, 60000)
    return () => clearInterval(localInterval.current)
  }, [weather])

  
  useEffect(() => {
    if (cityHour !== null && cityHour !== undefined) setHour(cityHour)
  }, [cityHour])

  useEffect(() => {
    if (weather) setWeatherType(getWeatherType(weather))
  }, [weather, getWeatherType])

  useEffect(() => {
    if (showWelcome) return
    if (currentSound.current) {
      currentSound.current.fade(currentSound.current.volume(), 0, 1500)
      setTimeout(() => { currentSound.current?.unload(); currentSound.current = null }, 1600)
    }
    const config = soundConfig[weatherType]
    if (config && soundEnabled) {
      const sound = new Howl({ ...config, html5: true })
      sound.play()
      sound.fade(0, config.volume, 1500)
      currentSound.current = sound
    }
    return () => { currentSound.current?.unload(); currentSound.current = null }
  }, [weatherType, soundEnabled, showWelcome, soundTrigger])

  const handleWelcomeClose = () => setShowWelcome(false)

  const handleSearch = (city) => {
    fetchWeather(city)
    setSoundTrigger(prev => prev + 1)
  }

  const isDark = ['rain', 'thunderstorm'].includes(weatherType)
  const isNight = hour >= 20 || hour < 6
  const textColor = (isDark || isNight) ? 'rgba(220,235,255,0.85)' : 'rgba(15,15,25,0.75)'
  const mutedColor = (isDark || isNight) ? 'rgba(180,210,255,0.4)' : 'rgba(15,15,25,0.35)'

  const toggleSound = () => {
    setSoundEnabled((prev) => {
      if (prev && currentSound.current) {
        currentSound.current.fade(currentSound.current.volume(), 0, 600)
        setTimeout(() => currentSound.current?.pause(), 650)
      } else if (!prev && currentSound.current) {
        currentSound.current.play()
        currentSound.current.fade(0, soundConfig[weatherType]?.volume || 0.3, 600)
      }
      return !prev
    })
  }

  return (
    <div style={{ minHeight: '100vh', position: 'relative', overflow: 'hidden' }}>
      <WeatherBackground weatherType={weatherType} hour={hour} />

      <AnimatePresence>
        {showWelcome && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            style={{
              position: 'fixed', inset: 0, zIndex: 100,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: 'rgba(0,0,0,0.35)', backdropFilter: 'blur(8px)',
            }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -10 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              style={{
                background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(32px)',
                border: '1px solid rgba(255,255,255,0.25)', borderRadius: '28px',
                padding: '52px 48px', maxWidth: '420px', width: '90%',
                textAlign: 'center', fontFamily: "'Cormorant Garamond', Georgia, serif",
                color: 'rgba(255,255,255,0.92)',
              }}
            >
              <div style={{ fontSize: '48px', marginBottom: '16px' }}>
                {isNight ? '🌙' : '🌤'}
              </div>
              <h2 style={{ fontSize: '32px', fontWeight: 300, letterSpacing: '0.04em', marginBottom: '12px' }}>
                Welcome
              </h2>
              <p style={{ fontSize: '15px', fontStyle: 'italic', lineHeight: 1.8, color: 'rgba(255,255,255,0.6)', marginBottom: '8px' }}>
                A place to feel the weather,<br />Not just see it.
              </p>
              <p style={{ fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', marginBottom: '36px' }}>
                ♪ Ambient sounds included
              </p>
              <motion.button
                onClick={handleWelcomeClose}
                whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                style={{
                  padding: '14px 40px', borderRadius: '50px',
                  border: '1px solid rgba(255,255,255,0.3)',
                  background: 'rgba(255,255,255,0.15)',
                  color: 'rgba(255,255,255,0.9)', fontSize: '14px',
                  fontFamily: "'Cormorant Garamond', Georgia, serif",
                  letterSpacing: '0.15em', cursor: 'pointer',
                }}
              >
                enter
              </motion.button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div style={{
        position: 'relative', zIndex: 1, minHeight: '100vh',
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        justifyContent: 'center', padding: '40px 24px', gap: '32px',
        fontFamily: "'Cormorant Garamond', Georgia, serif",
      }}>
        <motion.div
          initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: 'easeOut' }}
          style={{ textAlign: 'center' }}
        >
          <div style={{ fontSize: '11px', letterSpacing: '0.4em', textTransform: 'uppercase', color: mutedColor, marginBottom: '8px' }}>
            weather · atmosphere · feeling
          </div>
          <h1 style={{ fontSize: 'clamp(28px, 5vw, 42px)', fontWeight: 300, color: textColor, letterSpacing: '0.05em', margin: 0 }}>
            How does the sky feel?
          </h1>
        </motion.div>

        <SearchBar onSearch={handleSearch} loading={loading} isDark={isDark || isNight} />

        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              style={{ fontSize: '14px', fontStyle: 'italic', color: isDark ? 'rgba(255,160,160,0.8)' : 'rgba(160,40,40,0.7)', letterSpacing: '0.02em' }}
            >
              {error}
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {weather && !loading && (
            <motion.div
              key={weather.id}
              initial={{ opacity: 0, scale: 0.96, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: -8 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              style={{ width: '100%', display: 'flex', justifyContent: 'center' }}
            >
              <WeatherCard weather={weather} weatherType={weatherType} hour={hour} minute={cityMinute} />
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {loading && (
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              style={{ fontSize: '14px', fontStyle: 'italic', color: mutedColor, letterSpacing: '0.15em' }}
            >
              looking at the sky...
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          onClick={toggleSound}
          whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }}
          style={{
            position: 'fixed', bottom: '28px', right: '28px',
            padding: '10px 18px', borderRadius: '50px',
            border: `1px solid ${mutedColor}`,
            background: (isDark || isNight) ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.35)',
            backdropFilter: 'blur(12px)', color: textColor,
            fontSize: '12px', fontFamily: "'Cormorant Garamond', Georgia, serif",
            letterSpacing: '0.15em', cursor: 'pointer',
          }}
        >
          {soundEnabled ? '♪ sound on' : '♪ sound off'}
        </motion.button>
      </div>
    </div>
  )
}