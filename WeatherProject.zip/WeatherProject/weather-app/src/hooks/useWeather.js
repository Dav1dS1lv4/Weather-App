import { useState, useCallback } from 'react'
import axios from 'axios'

const API_KEY = ''
const BASE_URL = 'https://api.openweathermap.org/data/2.5/weather'

export function useWeather() {
  const [weather, setWeather] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [cityHour, setCityHour] = useState(null)
  const [cityMinute, setCityMinute] = useState(null)

  const fetchWeather = useCallback(async (city) => {
    if (!city.trim()) return
    setLoading(true)
    setError(null)
    try {
      const { data } = await axios.get(BASE_URL, {
        params: { q: city, appid: API_KEY, units: 'metric', lang: 'en' },
      })
      setWeather(data)

      const utcSeconds = Math.floor(Date.now() / 1000)
      const localSeconds = utcSeconds + data.timezone
      const localDate = new Date(localSeconds * 1000)
      setCityHour(localDate.getUTCHours())
      setCityMinute(localDate.getUTCMinutes()) // ← NOVO

    } catch (err) {
      if (err.response?.status === 404) {
        setError('City not found, try another city.')
      } else {
        setError('Verify your API key.')
      }
      setWeather(null)
      setCityHour(null)
      setCityMinute(null)
    } finally {
      setLoading(false)
    }
  }, [])

  const getWeatherType = (weatherData) => {
    if (!weatherData) return 'clear'
    const id = weatherData.weather[0].id
    if (id >= 200 && id < 300) return 'thunderstorm'
    if (id >= 300 && id < 600) return 'rain'
    if (id >= 600 && id < 700) return 'snow'
    if (id >= 700 && id < 800) return 'mist'
    if (id === 800) return 'clear'
    return 'clouds'
  }

  return { weather, loading, error, fetchWeather, getWeatherType, cityHour, cityMinute } // ← cityMinute adicionado
}