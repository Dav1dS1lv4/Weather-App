import { useState } from 'react'
import { motion } from 'framer-motion'

export default function SearchBar({ onSearch, loading, isDark }) {
  const [value, setValue] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    if (value.trim()) onSearch(value.trim())
  }

  const textColor = isDark ? 'rgba(255,255,255,0.9)' : 'rgba(20,20,30,0.85)'
  const borderColor = isDark ? 'rgba(255,255,255,0.2)' : 'rgba(20,20,30,0.2)'

  return (
    <motion.form
      onSubmit={handleSubmit}
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: 'easeOut' }}
      style={{ display: 'flex', gap: '10px', width: '100%', maxWidth: '480px' }}
    >
      <style>{`
        .weather-input::placeholder { color: ${isDark ? 'rgba(255,255,255,0.4)' : 'rgba(20,20,30,0.35)'}; }
        .weather-input:focus { outline: none; border-color: ${isDark ? 'rgba(255,255,255,0.5)' : 'rgba(20,20,30,0.5)'}; }
      `}</style>

      <input
        className="weather-input"
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Lisbon , Tokyo, New York..."
        style={{
          flex: 1,
          padding: '14px 20px',
          borderRadius: '50px',
          border: `1px solid ${borderColor}`,
          background: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.45)',
          backdropFilter: 'blur(16px)',
          color: textColor,
          fontSize: '15px',
          fontFamily: "'Cormorant Garamond', Georgia, serif",
          letterSpacing: '0.02em',
          transition: 'border-color 0.3s',
        }}
      />

      <motion.button
        type="submit"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.97 }}
        disabled={loading}
        style={{
          padding: '14px 24px',
          borderRadius: '50px',
          border: `1px solid ${borderColor}`,
          background: isDark ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.55)',
          backdropFilter: 'blur(16px)',
          color: textColor,
          fontSize: '14px',
          fontFamily: "'Cormorant Garamond', Georgia, serif",
          letterSpacing: '0.08em',
          cursor: loading ? 'wait' : 'pointer',
          whiteSpace: 'nowrap',
        }}
      >
        {loading ? '...' : 'Search'}
      </motion.button>
    </motion.form>
  )
}