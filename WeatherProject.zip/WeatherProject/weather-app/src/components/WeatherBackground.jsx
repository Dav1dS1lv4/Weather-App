import { motion, AnimatePresence } from 'framer-motion'

const stars = Array.from({ length: 120 }, (_, i) => ({
  id: i,
  top: Math.random() * 100,
  left: Math.random() * 100,
  size: 1 + Math.random() * 2.5,
  duration: 2 + Math.random() * 4,
  delay: Math.random() * 5,
  opacity: 0.4 + Math.random() * 0.6,
}))

const rainParticles = Array.from({ length: 80 }, (_, i) => ({
  id: i,
  left: Math.random() * 100,
  delay: Math.random() * 2,
  duration: 0.6 + Math.random() * 0.6,
  opacity: 0.3 + Math.random() * 0.4,
}))

const snowParticles = Array.from({ length: 50 }, (_, i) => ({
  id: i,
  left: Math.random() * 100,
  delay: Math.random() * 5,
  duration: 4 + Math.random() * 4,
  size: 3 + Math.random() * 5,
  drift: (Math.random() - 0.5) * 60,
}))

function getTimePhase(hour) {
  if (hour >= 5 && hour < 7) return 'dawn'
  if (hour >= 7 && hour < 12) return 'morning'
  if (hour >= 12 && hour < 17) return 'day'
  if (hour >= 17 && hour < 20) return 'sunset'
  if (hour >= 20 && hour < 23) return 'dusk'
  return 'night'
}

const weatherThemes = {
  clear: {
    day:     { bg: 'linear-gradient(160deg, #f5c842 0%, #f1af63 45%, #e15a5a 100%)', orbs: ['#ffe08a', '#ffd166', '#ffb347'] },
    dawn:    { bg: 'linear-gradient(160deg, #f9a86c 0%, #f47c60 40%, #c45c7a 100%)', orbs: ['#fdc49a', '#f7906a', '#d9607a'] },
    morning: { bg: 'linear-gradient(160deg, #f7c97a 0%, #f5a84a 45%, #e88c3a 100%)', orbs: ['#fde0a0', '#f7c070', '#f0a050'] },
    sunset:  { bg: 'linear-gradient(160deg, #e8703a 0%, #c04a6a 45%, #7a2a8a 100%)', orbs: ['#f0905a', '#d0607a', '#9a3a8a'] },
    dusk:    { bg: 'linear-gradient(160deg, #1a1a4a 0%, #2a1a5a 50%, #0f0f2a 100%)', orbs: ['#2a2a6a', '#1a1a4a', '#251535'] },
    night:   { bg: 'linear-gradient(160deg, #080820 0%, #0f0f35 50%, #050515 100%)', orbs: ['#101030', '#0a0a25', '#150f30'], stars: true },
  },
  clouds: {
    day:     { bg: 'linear-gradient(160deg, #9ab0c8 0%, #7a93ae 45%, #5c7a96 100%)', orbs: ['#c8d8e8', '#b0c4d8', '#a0b8cc'] },
    dawn:    { bg: 'linear-gradient(160deg, #b08898 0%, #907090 50%, #6a5080 100%)', orbs: ['#c8a0b0', '#a08098', '#806888'] },
    morning: { bg: 'linear-gradient(160deg, #a8b8c8 0%, #8898b0 45%, #6a8098 100%)', orbs: ['#c0d0e0', '#a8b8cc', '#90a8bc'] },
    sunset:  { bg: 'linear-gradient(160deg, #c07858 0%, #906080 50%, #603060 100%)', orbs: ['#d09070', '#a07090', '#704070'] },
    dusk:    { bg: 'linear-gradient(160deg, #252540 0%, #1a1a35 50%, #101025 100%)', orbs: ['#353555', '#252545', '#1a1a38'] },
    night:   { bg: 'linear-gradient(160deg, #131325 0%, #0f0f20 50%, #0a0a18 100%)', orbs: ['#1e1e35', '#161628', '#121222'], stars: true },
  },
  rain: {
    day:     { bg: 'linear-gradient(160deg, #1a2a4a 0%, #1f3a5f 50%, #162840 100%)', orbs: ['#2a4a7f', '#1e3d6e', '#253d60'] },
    dawn:    { bg: 'linear-gradient(160deg, #1a2035 0%, #251830 50%, #101525 100%)', orbs: ['#2a2a4a', '#1e1835', '#151525'] },
    morning: { bg: 'linear-gradient(160deg, #1e3050 0%, #243a60 50%, #182840 100%)', orbs: ['#2e4a70', '#223860', '#1e3050'] },
    sunset:  { bg: 'linear-gradient(160deg, #1a1530 0%, #2a1535 50%, #100f20 100%)', orbs: ['#2a1a40', '#1e1230', '#150f25'] },
    dusk:    { bg: 'linear-gradient(160deg, #0f1020 0%, #121525 50%, #0a0c18 100%)', orbs: ['#1a1a30', '#121525', '#0e1020'] },
    night:   { bg: 'linear-gradient(160deg, #080c15 0%, #0a0f1e 50%, #060810 100%)', orbs: ['#101525', '#0c1020', '#080c18'] },
  },
  thunderstorm: {
    day:     { bg: 'linear-gradient(160deg, #0d1117 0%, #1a1f2e 50%, #0f1520 100%)', orbs: ['#1e2a3a', '#141c28', '#1a2030'] },
    dawn:    { bg: 'linear-gradient(160deg, #0a0c12 0%, #12151e 50%, #080c14 100%)', orbs: ['#161c28', '#101520', '#0e1218'] },
    morning: { bg: 'linear-gradient(160deg, #0d1117 0%, #1a1f2e 50%, #0f1520 100%)', orbs: ['#1e2a3a', '#141c28', '#1a2030'] },
    sunset:  { bg: 'linear-gradient(160deg, #0a0810 0%, #150c18 50%, #080610 100%)', orbs: ['#180e20', '#100a18', '#0c0810'] },
    dusk:    { bg: 'linear-gradient(160deg, #080810 0%, #0c0c18 50%, #060608 100%)', orbs: ['#101018', '#0c0c14', '#080810'] },
    night:   { bg: 'linear-gradient(160deg, #050508 0%, #08080f 50%, #030305 100%)', orbs: ['#0c0c12', '#08080e', '#060608'] },
  },
  snow: {
    day:     { bg: 'linear-gradient(160deg, #dce8f5 0%, #c8dcea 50%, #b8cfe0 100%)', orbs: ['#eaf3fc', '#daeaf8', '#cce0f0'] },
    dawn:    { bg: 'linear-gradient(160deg, #c8c0d8 0%, #b0a8c8 50%, #9898b8 100%)', orbs: ['#d8d0e8', '#c0b8d8', '#a8a8c8'] },
    morning: { bg: 'linear-gradient(160deg, #d0dff0 0%, #bcd0e8 50%, #aac0da 100%)', orbs: ['#e0eef8', '#ccdff0', '#b8cfe8'] },
    sunset:  { bg: 'linear-gradient(160deg, #c8a8b8 0%, #a888a8 50%, #887898 100%)', orbs: ['#d8b8c8', '#b898b8', '#9888a8'] },
    dusk:    { bg: 'linear-gradient(160deg, #202035 0%, #181828 50%, #101020 100%)', orbs: ['#303048', '#202038', '#181828'] },
    night:   { bg: 'linear-gradient(160deg, #121220 0%, #0e0e1a 50%, #0a0a14 100%)', orbs: ['#1e1e30', '#161625', '#101018'], stars: true },
  },
  mist: {
    day:     { bg: 'linear-gradient(160deg, #b0bec5 0%, #90a4ae 50%, #78909c 100%)', orbs: ['#cfd8dc', '#b0bec5', '#a0b0b8'] },
    dawn:    { bg: 'linear-gradient(160deg, #a89898 0%, #907878 50%, #786060 100%)', orbs: ['#c0a8a8', '#a08888', '#887070'] },
    morning: { bg: 'linear-gradient(160deg, #a8b8c0 0%, #889aa5 50%, #708090 100%)', orbs: ['#c0d0d8', '#a8b8c0', '#90a0ac'] },
    sunset:  { bg: 'linear-gradient(160deg, #906870 0%, #705060 50%, #503848 100%)', orbs: ['#a07880', '#806070', '#604858'] },
    dusk:    { bg: 'linear-gradient(160deg, #1e1e2e 0%, #181820 50%, #101018 100%)', orbs: ['#2e2e3e', '#202030', '#181820'] },
    night:   { bg: 'linear-gradient(160deg, #101018 0%, #0c0c14 50%, #080810 100%)', orbs: ['#1a1a28', '#121220', '#0e0e18'] },
  },
}

function Stars() {
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
      {stars.map((s) => (
        <motion.div
          key={s.id}
          style={{
            position: 'absolute', top: `${s.top}%`, left: `${s.left}%`,
            width: `${s.size}px`, height: `${s.size}px`,
            borderRadius: '50%', background: 'white',
          }}
          animate={{ opacity: [s.opacity * 0.3, s.opacity, s.opacity * 0.3] }}
          transition={{ duration: s.duration, repeat: Infinity, delay: s.delay, ease: 'easeInOut' }}
        />
      ))}
    </div>
  )
}

function RainParticles() {
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
      {rainParticles.map((p) => (
        <motion.div
          key={p.id}
          style={{
            position: 'absolute', top: '-10px', left: `${p.left}%`,
            width: '1px', height: '18px',
            background: 'rgba(180,210,255,0.5)', borderRadius: '2px',
          }}
          animate={{ y: ['0vh', '110vh'] }}
          transition={{ duration: p.duration, repeat: Infinity, delay: p.delay, ease: 'linear' }}
          initial={{ opacity: p.opacity }}
        />
      ))}
    </div>
  )
}

function SnowParticles() {
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
      {snowParticles.map((p) => (
        <motion.div
          key={p.id}
          style={{
            position: 'absolute', top: '-20px', left: `${p.left}%`,
            width: `${p.size}px`, height: `${p.size}px`,
            borderRadius: '50%', background: 'rgba(255,255,255,0.85)',
          }}
          animate={{ y: ['0vh', '110vh'], x: [0, p.drift] }}
          transition={{ duration: p.duration, repeat: Infinity, delay: p.delay, ease: 'easeInOut' }}
        />
      ))}
    </div>
  )
}

function LightningEffect() {
  return (
    <motion.div
      style={{ position: 'absolute', inset: 0, background: 'rgba(200,220,255,0.15)', pointerEvents: 'none' }}
      animate={{ opacity: [0, 0, 0, 1, 0, 0.5, 0, 0, 0, 0] }}
      transition={{ duration: 6, repeat: Infinity, repeatDelay: 3 }}
    />
  )
}

export default function WeatherBackground({ weatherType, hour }) {
  const phase = getTimePhase(hour)
  const theme = weatherThemes[weatherType] || weatherThemes.clear
  const current = theme[phase] || theme.day
  const showStars = current.stars === true
  const themeKey = `${weatherType}-${phase}`

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={themeKey}
        style={{ position: 'fixed', inset: 0, zIndex: 0, background: current.bg }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 1.8, ease: 'easeInOut' }}
      >
        {current.orbs.map((color, i) => (
          <motion.div
            key={i}
            style={{
              position: 'absolute', borderRadius: '50%',
              background: color, opacity: 0.35, filter: 'blur(80px)',
              width: `${300 + i * 80}px`, height: `${300 + i * 80}px`,
              top: `${[10, 40, 60][i]}%`, left: `${[60, 10, 50][i]}%`,
            }}
            animate={{ x: [0, 30 + i * 10, -20, 0], y: [0, -20, 30 + i * 8, 0], scale: [1, 1.05, 0.97, 1] }}
            transition={{ duration: 10 + i * 3, repeat: Infinity, ease: 'easeInOut' }}
          />
        ))}

        {showStars && <Stars />}
        {(weatherType === 'rain' || weatherType === 'thunderstorm') && <RainParticles />}
        {weatherType === 'snow' && <SnowParticles />}
        {weatherType === 'thunderstorm' && <LightningEffect />}

        <div style={{
          position: 'absolute', inset: 0, opacity: 0.04,
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
          backgroundRepeat: 'repeat', backgroundSize: '128px', pointerEvents: 'none',
        }} />
      </motion.div>
    </AnimatePresence>
  )
}