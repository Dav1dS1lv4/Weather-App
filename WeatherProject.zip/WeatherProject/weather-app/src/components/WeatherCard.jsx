import { motion } from 'framer-motion'

const poetry = {
  clear:        { label: 'Clear Sky',    verse: 'Light lays itself over everything without asking permission.' },
  clouds:       { label: 'Cloudy',       verse: 'Clouds write stories that the wind erases.' },
  rain:         { label: 'Rain',         verse: 'The rain asks questions the ground cannot answer.' },
  thunderstorm: { label: 'Thunderstorm', verse: 'The sky remembers that it too has anger sometimes.' },
  snow:         { label: 'Snow',         verse: 'Silence has this weight — white and soft.' },
  mist:         { label: 'Mist',         verse: 'Everything exists a little less, and for that it is more beautiful.' },
}

const weatherIcons = {
  clear: '☀',
  clouds: '☁',
  rain: '⛆',
  thunderstorm: '⚡',
  snow: '❄',
  mist: '≋',
}

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.12 } },
}

const item = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
}

const font = "'Inter', -apple-system, sans-serif"

export default function WeatherCard({ weather, weatherType, hour, minute }) {
  const { label, verse } = poetry[weatherType] || poetry.clear
  const isDark = ['rain', 'thunderstorm'].includes(weatherType)
  const textColor = isDark ? 'rgba(220,235,255,0.92)' : 'rgba(15,15,25,0.85)'
  const mutedColor = isDark ? 'rgba(180,210,255,0.45)' : 'rgba(15,15,25,0.38)'
  const borderColor = isDark ? 'rgba(255,255,255,0.07)' : 'rgba(255,255,255,0.5)'
  const bgColor = isDark ? 'rgba(10,18,35,0.35)' : 'rgba(255,255,255,0.28)'
  const dividerColor = isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.08)'

  const temp = Math.round(weather.main.temp)
  const feelsLike = Math.round(weather.main.feels_like)
  const humidity = weather.main.humidity
  const wind = Math.round(weather.wind.speed * 3.6)

  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      style={{
        width: '100%',
        maxWidth: '420px',
        background: bgColor,
        backdropFilter: 'blur(24px)',
        borderRadius: '20px',
        border: `1px solid ${borderColor}`,
        padding: '36px 40px',
        color: textColor,
        fontFamily: font,
      }}
    >
      {/* Icon + label */}
      <motion.div variants={item} style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '28px' }}>
        <span style={{ fontSize: '22px', lineHeight: 1 }}>{weatherIcons[weatherType] || '☀'}</span>
        <span style={{ fontSize: '11px', fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', color: mutedColor }}>
          {label}
        </span>
      </motion.div>

      {/* Temperatura + hora — mesmo tamanho, alinhados */}
      <motion.div variants={item} style={{ display: 'flex', alignItems: 'center', gap: '0px', marginBottom: '6px' }}>
        <div style={{ fontSize: 'clamp(64px, 12vw, 80px)', fontWeight: 200, lineHeight: 1, letterSpacing: '-0.03em' }}>
          {temp}°
        </div>
        <div style={{
          width: '1px', height: '56px',
          background: dividerColor,
          margin: '0 20px',
          alignSelf: 'center',
        }} />
        <div>
          <div style={{ fontSize: 'clamp(64px, 12vw, 80px)', fontWeight: 200, lineHeight: 1, letterSpacing: '-0.03em' }}>
            {String(hour).padStart(2, '0')}:{String(minute ?? 0).padStart(2, '0')}
          </div>
          <div style={{ fontSize: '10px', fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', color: mutedColor, marginTop: '6px' }}>
            local time
          </div>
        </div>
      </motion.div>

      {/* Cidade */}
      <motion.div variants={item} style={{ fontSize: '22px', fontWeight: 300, letterSpacing: '-0.01em', marginBottom: '6px', marginTop: '16px' }}>
        {weather.name}, {weather.sys.country}
      </motion.div>

      {/* Verso */}
      <motion.div variants={item} style={{
        fontSize: '13px', fontWeight: 300, fontStyle: 'italic',
        color: mutedColor, lineHeight: 1.7, marginBottom: '28px',
        borderLeft: `2px solid ${dividerColor}`, paddingLeft: '14px',
      }}>
        {verse}
      </motion.div>

      {/* Stats */}
      <motion.div variants={item} style={{
        display: 'grid', gridTemplateColumns: '1fr 1fr 1fr',
        gap: '8px', borderTop: `1px solid ${dividerColor}`, paddingTop: '22px',
      }}>
        {[
          { label: 'feels like', value: `${feelsLike}°` },
          { label: 'humidity',   value: `${humidity}%` },
          { label: 'wind',       value: `${wind} km/h` },
        ].map(({ label, value }) => (
          <div key={label} style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '10px', fontWeight: 500, letterSpacing: '0.15em', textTransform: 'uppercase', color: mutedColor, marginBottom: '6px' }}>
              {label}
            </div>
            <div style={{ fontSize: '20px', fontWeight: 300 }}>{value}</div>
          </div>
        ))}
      </motion.div>
    </motion.div>
  )
}